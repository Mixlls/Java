package Homework3.two;
/*
Nattawat itpma
6509618150
15
 */
public class GridData {
    private boolean isOpen;
    private boolean hasBomb;
    
    GridData(){
        isOpen = false;
        hasBomb = false;
    }
    public boolean getOpen() {
        return isOpen;
    }
    public void setOpen(boolean isOpen) {
        this.isOpen = isOpen;
    }
    
    public boolean getHasBomb() {
        return hasBomb;
    }
    public void setHasBomb(boolean haslean) {
        this.hasBomb = haslean;
    }

    
}
