package Homework3.two;
/*
Nattawat itpma
6509618150
15
 */
public class BomberGameTest {
    public static void main(String[] args) {
        BomberGame bg = new BomberGame(4, 2);
        bg.play();
    }
}
