package Homework3.four;
/*
Nattawat itpma
6509618150
15
 */
public interface Edible {
	public String getName();
	public String getShop();
	public float getCalorie();
	public void printInfo();
}
