package Homework3.one;
/*
Nattawat itpma
6509618150
15
 */
public class StudentScore {
    private String id;
    private int score;
    public StudentScore(String id,int score){
        this.id = id;
        this.score = score;
    }
    public String getld(){
        return id;
    }
    public int getScore(){
        return score;
    }
}
